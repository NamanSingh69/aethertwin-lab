"""Measured multi-station registration, RGB-D TSDF and oriented-cloud Poisson."""
from pathlib import Path
import copy
import json
import numpy as np
import open3d as o3d
from core.se3_math import transform_points,inverse,so3_exp
from .icp_pose_graph import as_cloud,ICPPoseGraph,point_to_plane_icp,global_registration


def fit_floor_transform(points,normals=None,voxel_size=.08):
    """Find a low gravity-horizontal support plane, independent of scanner height.

    This assumes a gravity-aligned initial world z direction. A missing/weak
    measured support plane is an error; it cannot justify treating z=0 as floor.
    """
    p=np.asarray(points,dtype=float)[:,:3]
    if len(p)<30:raise ValueError("Floor calibration requires at least 30 measured points")
    if normals is None:
        cloud=as_cloud(p,0);cloud.estimate_normals(o3d.geometry.KDTreeSearchParamHybrid(radius=max(.35,4*voxel_size),max_nn=40));normals=np.asarray(cloud.normals)
    horizontal=p[np.abs(np.asarray(normals)[:,2])>.85]
    if len(horizontal)<20:raise ValueError("No measured gravity-horizontal floor support")
    # The low quantile avoids below-floor outliers while rejecting upper bench
    # surfaces. Heights are relative, so scanner-origin recordings at -1.6m work.
    cutoff=np.quantile(horizontal[:,2],.35)+max(.05,voxel_size)
    candidate=horizontal[horizontal[:,2]<=cutoff]
    plane,inliers=as_cloud(candidate,0).segment_plane(max(.025,voxel_size*.2),3,500)
    n=np.asarray(plane[:3]);d=float(plane[3])
    if n[2]<0:n=-n;d=-d
    support=candidate[inliers]
    if n[2]<.9 or len(support)<20:raise ValueError("Floor fit failed gravity/support checks")
    support_span=np.ptp(support[:,:2],axis=0);scene_span=np.maximum(np.ptp(p[:,:2],axis=0),1e-6)
    if min(support_span)<.5 or np.prod(support_span)<.15*np.prod(scene_span):
        raise ValueError("Floor fit has insufficient measured spatial coverage")
    axis=np.cross(n,[0,0,1]);theta=np.arccos(np.clip(n[2],-1,1))
    R=np.eye(3) if np.linalg.norm(axis)<1e-10 else so3_exp(axis/np.linalg.norm(axis)*theta)
    T=np.eye(4);T[:3,:3]=R;T[2,3]=d
    return T,{'normal':n.tolist(),'offset':d,'support_points':len(support),'height_before_alignment':float(-d/n[2])}


class StaticTwinBuilder:
    def __init__(self,voxel_size=.08,poisson_depth=7,seed=0):
        self.voxel_size=float(voxel_size);self.poisson_depth=int(poisson_depth);self.points=np.empty((0,3));self.mesh=o3d.geometry.TriangleMesh()
        self.poisson_mesh=o3d.geometry.TriangleMesh();self.tsdf_mesh=o3d.geometry.TriangleMesh();self.watertight_mesh=o3d.geometry.TriangleMesh();self.floor_transform=np.eye(4);self.poses=[];self.report={};self.seed=int(seed)
    def build(self,frames):
        frames=list(frames)
        if not frames:raise ValueError("No commissioning scans supplied")
        self.watertight_mesh=o3d.geometry.TriangleMesh()
        o3d.utility.random.seed(self.seed)
        graph=ICPPoseGraph(voxel_size=max(.1,self.voxel_size),max_keyframes=None);clouds=[];coarse_reports=[]
        for f in frames:
            cloud=np.asarray(f.lidar_points[:,:3]);clouds.append(cloud)
            if len(cloud)<10:raise ValueError("Insufficient commissioning returns")
            if graph.clouds:
                # Supplied station pose is an initialization, refined against observations.
                guess=f.sensor_pose_world;prior_relative=inverse(graph.poses[-1])@guess
                known_prior=bool(f.diagnostics.get('pose_prior_valid',not np.allclose(guess,np.eye(4))))
                coarse_report={'station':len(clouds)-1,'prior_declared':known_prior,'method':'pose_prior'}
                try:
                    coarse,fitness=global_registration(cloud,graph.clouds[-1]);coarse_report['fpfh_ransac_fitness']=fitness
                    if not known_prior:
                        coarse_refined,coarse_diag=point_to_plane_icp(cloud,graph.clouds[-1],coarse,voxel=max(.1,self.voxel_size))
                        prior_refined,prior_diag=point_to_plane_icp(cloud,graph.clouds[-1],prior_relative,voxel=max(.1,self.voxel_size))
                        def score(diag):return diag['rmse']/max(diag['fitness'],1e-6)+.1*(1-diag['fitness'])
                        if score(coarse_diag)<score(prior_diag):guess=graph.poses[-1]@coarse_refined;coarse_report['method']='fpfh_ransac'
                except ValueError as error:coarse_report['fpfh_ransac_error']=str(error)
                coarse_reports.append(coarse_report)
                try:graph.add_scan(cloud,guess)
                except ValueError:
                    relative,fitness=global_registration(cloud,graph.clouds[-1])
                    graph.add_scan(cloud,graph.poses[-1]@relative)
            else:graph.add_scan(cloud,f.sensor_pose_world)
        # Multi-station loops need not wait for a long mobile odometry history.
        for a in range(len(graph.clouds)):
            for b in range(a+2,len(graph.clouds)):
                initial=inverse(graph.poses[a])@graph.poses[b]
                T,diag=point_to_plane_icp(graph.clouds[b],graph.clouds[a],initial,voxel=max(.1,self.voxel_size))
                if diag['fitness']>.4 and diag['rmse']<.15:graph.edges.append((a,b,T,diag['information']))
        self.poses=graph.optimize()
        combined=np.concatenate([transform_points(T,p) for T,p in zip(self.poses,clouds)])
        cloud=as_cloud(combined,self.voxel_size)
        self.floor_transform,floor_report=fit_floor_transform(np.asarray(cloud.points),voxel_size=self.voxel_size)
        cloud.transform(self.floor_transform)
        self.points=np.asarray(cloud.points).copy();cloud.estimate_normals(o3d.geometry.KDTreeSearchParamHybrid(radius=self.voxel_size*4,max_nn=30))
        cloud.orient_normals_consistent_tangent_plane(20)
        # Poisson's native worker state can race after other OpenMP consumers
        # have run. Offline single-thread reconstruction is deterministic and
        # avoids the repeated-call crash without changing the reconstruction.
        self.poisson_mesh,density=o3d.geometry.TriangleMesh.create_from_point_cloud_poisson(cloud,depth=self.poisson_depth,n_threads=1)
        # Screened Poisson closes unobserved regions. Preserve this inferred
        # surface separately; never use its imputed closure for collision/free-space.
        closure_scale=1.1;raw_closed=self.poisson_mesh.is_watertight()
        if raw_closed:self.watertight_mesh=copy.deepcopy(self.poisson_mesh)
        else:
            expanded,_=o3d.geometry.TriangleMesh.create_from_point_cloud_poisson(cloud,depth=self.poisson_depth,scale=1.5,n_threads=1)
            if expanded.is_watertight():self.watertight_mesh=expanded;closure_scale=1.5
        density=np.asarray(density)
        if len(density):self.poisson_mesh.remove_vertices_by_mask(density<np.quantile(density,.02))
        self.poisson_mesh=self.poisson_mesh.crop(cloud.get_axis_aligned_bounding_box())
        self.poisson_mesh.compute_vertex_normals()
        volume=o3d.pipelines.integration.ScalableTSDFVolume(voxel_length=self.voxel_size,sdf_trunc=4*self.voxel_size,color_type=o3d.pipelines.integration.TSDFVolumeColorType.RGB8)
        integrated=0
        for frame,pose in zip(frames,self.poses):
            if frame.depth is None or frame.rgb is None or frame.calibration is None:continue
            rgbd=o3d.geometry.RGBDImage.create_from_color_and_depth(o3d.geometry.Image(np.asarray(frame.rgb).copy()),o3d.geometry.Image(np.asarray(frame.depth).copy()),depth_scale=1.,depth_trunc=6.,convert_rgb_to_intensity=False)
            K=frame.calibration.K;h,w=frame.depth.shape
            intrinsic=o3d.camera.PinholeCameraIntrinsic(w,h,K[0,0],K[1,1],K[0,2],K[1,2])
            Twc=self.floor_transform@pose@frame.calibration.T_lidar_camera
            volume.integrate(rgbd,intrinsic,inverse(Twc));integrated+=1
        tsdf=volume.extract_triangle_mesh();tsdf.compute_vertex_normals();self.tsdf_mesh=tsdf
        # Four sparse viewpoints can yield only small disconnected TSDF fragments.
        # Retain both reconstructions; present the better covered Poisson surface.
        self.mesh=tsdf if len(tsdf.triangles)>=.25*len(self.poisson_mesh.triangles) else self.poisson_mesh
        self.report={'stations':len(frames),'measured_points':len(self.points),'tsdf_frames':integrated,'tsdf_triangles':len(tsdf.triangles),'mesh_triangles':len(self.mesh.triangles),'pose_graph_edges':len(graph.edges),
                     'poisson_triangles':len(self.poisson_mesh.triangles),'watertight':self.mesh.is_watertight(),'unknown_space_inferred_free':False,'floor_fit':floor_report,
                     'watertight_visual_mesh':bool(len(self.watertight_mesh.triangles) and self.watertight_mesh.is_watertight()),
                     'watertight_visual_method':'uncropped_screened_poisson','watertight_visual_scale':closure_scale,
                     'watertight_visual_closure_inferred':True,'watertight_visual_is_collision_authority':False,
                     'coarse_registration':coarse_reports,
                     'graph':{k:v for k,v in graph.last_diagnostics.items() if np.isscalar(v)}}
        return self
    def save(self,path):
        path=Path(path);path.mkdir(parents=True,exist_ok=True)
        np.savez_compressed(path/'measured_map.npz',points=self.points,floor_transform=self.floor_transform,poses=np.array(self.poses),voxel_size=self.voxel_size)
        if len(self.mesh.vertices):o3d.io.write_triangle_mesh(str(path/'mesh.ply'),self.mesh)
        if len(self.tsdf_mesh.vertices):o3d.io.write_triangle_mesh(str(path/'tsdf_mesh.ply'),self.tsdf_mesh)
        if len(self.poisson_mesh.vertices):o3d.io.write_triangle_mesh(str(path/'poisson_mesh.ply'),self.poisson_mesh)
        if len(self.watertight_mesh.vertices):o3d.io.write_triangle_mesh(str(path/'watertight_mesh.ply'),self.watertight_mesh)
        elif (path/'watertight_mesh.ply').exists():(path/'watertight_mesh.ply').unlink()
        (path/'reconstruction.json').write_text(json.dumps(self.report,indent=2),encoding='utf-8')
    @classmethod
    def load(cls,path):
        path=Path(path)
        with np.load(path/'measured_map.npz',allow_pickle=False) as z:
            out=cls(float(z['voxel_size']));out.points=z['points'];out.floor_transform=z['floor_transform'];out.poses=list(z['poses'])
        if (path/'mesh.ply').exists():out.mesh=o3d.io.read_triangle_mesh(str(path/'mesh.ply'))
        if (path/'tsdf_mesh.ply').exists():out.tsdf_mesh=o3d.io.read_triangle_mesh(str(path/'tsdf_mesh.ply'))
        if not len(out.mesh.vertices):out.mesh=out.tsdf_mesh
        if (path/'poisson_mesh.ply').exists():out.poisson_mesh=o3d.io.read_triangle_mesh(str(path/'poisson_mesh.ply'))
        if (path/'watertight_mesh.ply').exists():out.watertight_mesh=o3d.io.read_triangle_mesh(str(path/'watertight_mesh.ply'))
        out.report=json.loads((path/'reconstruction.json').read_text(encoding='utf-8'));return out
