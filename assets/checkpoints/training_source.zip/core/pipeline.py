"""Production dataflow: observations -> localization -> map -> ML -> tracks -> routes.

This module never imports or accepts simulator ground truth. Commissioning is a
separate, explicitly empty-room sensor acquisition, not access to a scene mesh.
"""
from __future__ import annotations
from dataclasses import replace
from pathlib import Path
import json,time,threading,tempfile,uuid,shutil
from collections import deque
import numpy as np
import psutil
from scipy.spatial.transform import Rotation
from core.contracts import Detection3D,OrientedGeofence3D,PlannedTrajectory,TwinMasterFrameState,PALETTE
from core.se3_math import transform_points,inverse
from ingestion.sensor_synchronizer import fuse_frame
from ingestion.recorder_replayer import FrameRecorder
from slam_and_twin.imu_deskew import ContinuousTimeIMUDeskewer
from slam_and_twin.icp_pose_graph import ICPPoseGraph
from slam_and_twin.static_twin_builder import StaticTwinBuilder
from slam_and_twin.spatial_diff_engine import SpatialDiffEngine
from slam_and_twin.log_odds_octomap import SparseMultiReturnVoxelMap
from perception_ml.inference_engine import InferenceEngine
from perception_ml.eigen_descriptors import cluster_points,eigen_descriptors
from tracking_and_navigation.kalman_9dof_tracker import KalmanMultiObjectTracker
from tracking_and_navigation.risk_and_geofence import RiskGeofenceEngine
from tracking_and_navigation.traffic_heatmap import TrafficHeatmap
from tracking_and_navigation.safe_corridor_planner import PlannerGrid,SafeCorridorPlanner
from tracking_and_navigation.observed_navigation import integrate_commissioning_frame


def build_commissioned_assets(frames,path,config,progress=print):
    """Publish a complete bundle atomically; preserve the preceding bundle."""
    path=Path(path).resolve();path.parent.mkdir(parents=True,exist_ok=True)
    stage=Path(tempfile.mkdtemp(prefix=f'.{path.name}.building-',dir=path.parent)).resolve()
    backup=None
    try:
        result=_build_assets_into(frames,stage,config,progress)
        if path.exists():
            backup=path.with_name(f'{path.name}.previous-{uuid.uuid4().hex[:8]}')
            path.rename(backup)
        try:stage.rename(path)
        except BaseException:
            if backup is not None and not path.exists():backup.rename(path)
            raise
        if backup is not None:progress(f'Previous bundle preserved at {backup}')
        return result
    finally:
        if stage.exists():
            if stage.parent!=path.parent or not stage.name.startswith(f'.{path.name}.building-') or stage.is_symlink():
                raise RuntimeError('Refusing unexpected reconstruction staging cleanup')
            shutil.rmtree(stage)


def _build_assets_into(frames,path,config,progress=print):
    frames=list(frames);path=Path(path);path.mkdir(parents=True,exist_ok=True)
    progress('Registering measured commissioning scans and reconstructing TSDF/Poisson surfaces...')
    twin=StaticTwinBuilder(config['mapping']['twin_voxel_size']).build(frames);twin.save(path)
    # Navigation resolution explicitly matches its conservative observation map.
    static=SparseMultiReturnVoxelMap(config['planning']['resolution'],decay_rate=1.,max_age=float('inf'))
    with FrameRecorder(path/'commissioning') as recorder:
        for j,(frame,pose) in enumerate(zip(frames,twin.poses)):
            recorder.write(frame)
            measured=replace(frame,sensor_pose_world=twin.floor_transform@pose)
            progress(f'Carving measured navigation free space: station {j+1}/{len(frames)}')
            integrate_commissioning_frame(static,measured,camera_stride=1)
    static.save(path/'static_occupancy.npz')
    grid=PlannerGrid.from_voxel_map(static,bounds=config['planning']['bounds'],resolution=config['planning']['resolution'])
    grid.save(path/'planning_grid.npz')
    progress(f'Commissioning complete: {len(twin.points)} measured surface points; {int(grid.known.sum())} observed planning cells')
    return twin,static,grid


def load_commissioned_assets(path):
    path=Path(path)
    return StaticTwinBuilder.load(path),SparseMultiReturnVoxelMap.load(path/'static_occupancy.npz'),PlannerGrid.load(path/'planning_grid.npz')


def detections_from_prediction(prepared,probabilities,flow,embeddings,diff,config,flow_valid,sensor_origin):
    xyz=prepared.voxels.voxel_centers
    labels=probabilities.argmax(1);confidence=probabilities.max(1)
    novel=diff.foreground_mask(xyz,origin=sensor_origin)
    detections=[]
    for cls in range(2,7):
        selected=np.flatnonzero((labels==cls)&novel&(confidence>=config['perception']['confidence_threshold']))
        if not len(selected):continue
        clusters=cluster_points(xyz[selected],config['tracking']['cluster_eps'],config['tracking']['min_cluster_points'])
        for cluster in np.unique(clusters):
            if cluster<0:continue
            ids=selected[clusters==cluster];p=xyz[ids].astype(float)
            centered=p-p.mean(0)
            _,basis=np.linalg.eigh(centered.T@centered/max(len(p)-1,1));R=basis[:,::-1].copy()
            if np.linalg.det(R)<0:R[:,-1]*=-1
            local=centered@R;lo=local.min(0);hi=local.max(0)
            position=p.mean(0)+(lo+hi)/2@R.T;size=np.maximum(hi-lo,.10)
            prob=probabilities[ids].mean(0);mean_flow=flow[ids].mean(0)
            variance=float(np.var(flow[ids],axis=0).mean()+.0025)
            eigen=eigen_descriptors(p).mean(0)
            detections.append(Detection3D(position,size,R,prob,mean_flow,embeddings[ids].mean(0),p,eigen,flow_valid,variance))
    return detections


class LabPipeline:
    def __init__(self,config,checkpoint,twin,static_map,planning_grid,mobile=False):
        self.config=config;self.twin=twin;self.static_map=static_map;self.base_grid=planning_grid;self.mobile=mobile
        self.inference=InferenceEngine(checkpoint,config['device'],config['mapping']['voxel_size'],config['perception']['max_voxels'],
            config['perception'].get('neighbors',16),config['perception'].get('temporal_neighbors',12),config['perception'].get('rgbd_stride',3),
            config['perception'].get('range_image_height',24),config['perception'].get('range_image_width',96))
        self.diff=SpatialDiffEngine(twin.points,config['mapping']['tau0'],config['mapping']['beta'],config['mapping']['floor_epsilon'])
        self.occupancy=SparseMultiReturnVoxelMap(config['mapping']['voxel_size'],config['mapping']['decay_rate'],max_age=30.)
        self.deskewer=None
        reference=transform_points(inverse(twin.floor_transform),twin.points) if mobile else None
        self.odometry=ICPPoseGraph(reference_points=reference)
        self.tracker=KalmanMultiObjectTracker(model=config['tracking']['model'])
        self.risk=RiskGeofenceEngine();self.heatmap=TrafficHeatmap(bounds=config['planning']['bounds'][:4],resolution=config['planning']['resolution'])
        self.planner=SafeCorridorPlanner(planning_grid,radius=config['planning']['radius'],seed=config['seed'],
            mppi_samples=config['planning'].get('mppi_samples',96),mppi_iterations=config['planning'].get('mppi_iterations',2))
        self.planning_points=planning_grid.center(np.indices(planning_grid.shape).reshape(3,-1).T)
        # Precompute exact source-cell coverage for UNKNOWN coarse cells only.
        unknown_indices=np.argwhere(~planning_grid.known)
        lower=planning_grid.origin+unknown_indices*planning_grid.resolution
        first=np.floor((lower+1e-10)/self.occupancy.voxel_size).astype(np.int64)
        last=np.floor((lower+planning_grid.resolution-1e-10)/self.occupancy.voxel_size).astype(np.int64)
        count=int(np.ceil(planning_grid.resolution/self.occupancy.voxel_size))+1
        offsets=np.indices((count,count,count)).reshape(3,-1).T
        subcells=first[:,None]+offsets
        valid=np.all(subcells<=last[:,None],axis=-1)
        self.unknown_indices=unknown_indices
        self.unknown_queries=(subcells[valid]+.5)*self.occupancy.voxel_size
        self.unknown_owners=np.broadcast_to(np.arange(len(first))[:,None],valid.shape)[valid]
        self.start=np.array(config['planning']['start'],float);self.goal=np.array(config['planning']['goal'],float)
        self.robot_position=self.start.copy();self.robot_velocity=np.zeros(3)
        self.trajectory=PlannedTrajectory('not_requested',np.empty((0,3)),np.empty(0));self.trajectory_elapsed=0.
        self.geofences=[OrientedGeofence3D('Robotics cell',np.array([-.7,-.2,.9]),Rotation.from_euler('z',.2).as_matrix(),np.array([.7,.8,.9])),
            OrientedGeofence3D('Server rack',np.array([-4.8,3,1.]),np.eye(3),np.array([.6,.8,1.]))]
        xmin,xmax,ymin,ymax=config['planning']['bounds'][:4]
        resolution=config['planning']['resolution']
        x,y=np.meshgrid(np.arange(xmin,xmax,resolution),np.arange(ymin,ymax,resolution))
        self.floor_points=np.c_[x.ravel(),y.ravel(),np.full(x.size,.08)]
        self.frames=0;self.last_time=None;self.lock=threading.Lock();self.pending_goal=None
        self.alert_log=deque(maxlen=12);self.processing_ms=deque(maxlen=20000);self.memory_mb=deque(maxlen=20000)
        self.last_state=None;self.started=time.monotonic();self.dropped_snapshots=0

    def set_start_goal(self,start,goal):
        start=np.asarray(start,float);goal=np.asarray(goal,float)
        if start.shape!=(3,) or goal.shape!=(3,) or not np.isfinite(np.r_[start,goal]).all():raise ValueError('Start/goal require finite XYZ')
        with self.lock:self.pending_goal=(start.copy(),goal.copy())

    def export_trajectory(self,path=None):
        path=Path(path or 'artifacts/trajectory.csv');path.parent.mkdir(parents=True,exist_ok=True)
        with self.lock:
            points,times=self._remaining_trajectory()
            export=PlannedTrajectory(self.trajectory.status,points,times,self.trajectory.reason,self.trajectory.cost)
            self.planner.export(export,path)
        return str(path)

    def _remaining_trajectory(self):
        if self.trajectory.status!='ok':return np.empty((0,3)),np.empty(0)
        keep=self.trajectory.times>self.trajectory_elapsed+1e-9
        return np.vstack([self.robot_position,self.trajectory.points[keep]]),np.r_[0,self.trajectory.times[keep]-self.trajectory_elapsed]

    def _update_planning_grid(self):
        occupied=self.base_grid.occupied.copy();known=self.base_grid.known.copy()
        points=self.occupancy.occupied_points(.6)
        if len(points):
            size=self.occupancy.voxel_size
            first=np.floor((points-size/2-self.base_grid.origin+1e-10)/self.base_grid.resolution).astype(int)
            last=np.floor((points+size/2-self.base_grid.origin-1e-10)/self.base_grid.resolution).astype(int)
            count=int(np.ceil(size/self.base_grid.resolution))+1
            offsets=np.indices((count,count,count)).reshape(3,-1).T
            idx=first[:,None]+offsets
            valid=np.all((idx<=last[:,None])&(idx>=0)&(idx<self.base_grid.shape),axis=-1);idx=idx[valid]
            occupied[tuple(idx.T)]=True;known[tuple(idx.T)]=True
        if len(self.unknown_queries):
            values,observed=self.occupancy.query(self.unknown_queries,return_known=True)
            all_free=np.ones(len(self.unknown_indices),bool)
            np.logical_and.at(all_free,self.unknown_owners,observed&(values<-.2))
            ids=self.unknown_indices[all_free];known[tuple(ids.T)]=True
        grid=PlannerGrid(self.base_grid.origin,self.base_grid.resolution,occupied,known)
        self.planner.set_grid(grid)

    def process(self,raw_frame):
        start=time.perf_counter();timings={}
        if self.deskewer is None:self.deskewer=ContinuousTimeIMUDeskewer(initial_pose=raw_frame.sensor_pose_world,imu_to_lidar=raw_frame.imu_to_lidar)
        frame=self.deskewer.deskew_frame(raw_frame)
        pose=frame.sensor_pose_world
        aligned_time=frame.timestamp+frame.sweep_duration
        if self.mobile:
            corrected=self.odometry.add_scan(frame.lidar_points[:,:3],pose)
            if self.frames and self.frames%20==0:
                corrected=self.odometry.optimize()[-1]
            pose_dt=aligned_time-self.last_time if self.last_time is not None else raw_frame.sweep_duration
            if pose_dt<=0:raise ValueError('Localized sweep-end times must increase')
            velocity=(corrected[:3,3]-self.previous_pose[:3,3])/pose_dt if hasattr(self,'previous_pose') else self.deskewer.velocity
            self.deskewer.correct_state(corrected,velocity)
            pose=corrected
            self.previous_pose=corrected.copy()
        pose=self.twin.floor_transform@pose
        frame=replace(frame,sensor_pose_world=pose)
        frame=fuse_frame(frame)
        world_points=frame.lidar_points.copy();world_points[:,:3]=transform_points(pose,world_points[:,:3])
        timings['localization']=1000*(time.perf_counter()-start);stage=time.perf_counter()
        rgb=frame.painted_features[:,:3] if frame.painted_features is not None else None
        origins=pose[:3,3] if frame.lidar_origins is None else transform_points(pose,frame.lidar_origins)
        self.occupancy.voxelize_and_update(world_points,rgb,timestamp=aligned_time,origin=origins,
            beam_ids=frame.beam_ids,return_metadata_valid=frame.return_metadata_valid)
        if frame.gemini_rgbd_cloud is not None:
            dense=np.zeros((len(frame.gemini_rgbd_cloud),7),np.float32)
            dense[:,:3]=transform_points(pose,frame.gemini_rgbd_cloud[:,:3]);dense[:,3]=.5;dense[:,4:6]=1
            camera_pose=frame.calibration.T_lidar_camera if frame.camera_pose_in_lidar is None else frame.camera_pose_in_lidar
            camera_origin=(pose@camera_pose)[:3,3]
            self.occupancy.voxelize_and_update(dense,frame.gemini_rgbd_cloud[:,3:],timestamp=aligned_time,origin=camera_origin)
        if frame.rplidar_s2_points is not None:
            ring=np.zeros((len(frame.rplidar_s2_points),7),np.float32)
            ring[:,:3]=transform_points(pose,frame.rplidar_s2_points[:,:3]);ring[:,3]=.5;ring[:,4:6]=1
            ring_origin=transform_points(pose,frame.rplidar_origin_lidar[None])[0]
            self.occupancy.voxelize_and_update(ring,timestamp=aligned_time,origin=ring_origin)
        timings['occupancy']=1000*(time.perf_counter()-stage);stage=time.perf_counter()
        prepared,probs,flow,embedding=self.inference.infer(frame,world_points,self.diff.distances,self.occupancy.query)
        dt=frame.sweep_duration if self.last_time is None else max(1e-6,aligned_time-self.last_time)
        detections=detections_from_prediction(prepared,probs,flow,embedding,self.diff,self.config,self.inference.temporal_valid,pose[:3,3])
        entities=self.tracker.update(detections,aligned_time,dt)
        entities,self.geofences,alerts=self.risk.evaluate(entities,self.geofences,self.robot_position,self.robot_velocity)
        self.alert_log.extend(alerts);heat=self.heatmap.update(entities,aligned_time)
        risk,risk_colors=self.risk.compute_risk(self.floor_points,entities)
        timings['perception_tracking']=1000*(time.perf_counter()-stage);stage=time.perf_counter()
        with self.lock:
            if self.pending_goal is not None:
                self.start,self.goal=self.pending_goal;self.robot_position=self.start.copy();self.pending_goal=None
                self.trajectory=PlannedTrajectory('not_requested',np.empty((0,3)),np.empty(0))
            self._update_planning_grid()
            need_replan=self.frames%self.config['planning']['replan_interval']==0 or self.trajectory.status=='not_requested'
            if self.trajectory.status=='ok':
                remaining,remaining_times=self._remaining_trajectory()
                if not self.planner.path_clear(remaining,remaining_times,entities):
                    self.trajectory=PlannedTrajectory('invalidated',np.empty((0,3)),np.empty(0),'New observation invalidated remaining trajectory')
                    need_replan=True
            if need_replan:
                planning_risk=self.risk.compute_risk(self.planning_points,entities)[0].reshape(self.base_grid.shape)
                self.trajectory=self.planner.plan(self.robot_position,self.goal,
                    risk=planning_risk,ground=self.config['planning']['ground'],entities=entities)
                self.trajectory_elapsed=0.
            if self.trajectory.status=='ok' and len(self.trajectory.times)>1:
                previous=self.robot_position.copy();next_time=min(self.trajectory_elapsed+dt,self.trajectory.times[-1])
                proposed=np.array([np.interp(next_time,self.trajectory.times,self.trajectory.points[:,j]) for j in range(3)])
                if self.planner.segment_clear(previous,proposed,0.,dt,entities):
                    self.trajectory_elapsed=next_time;self.robot_position=proposed;self.robot_velocity=(proposed-previous)/dt
                else:
                    self.trajectory=PlannedTrajectory('invalidated',np.empty((0,3)),np.empty(0),'Proposed motion failed swept collision check')
                    self.robot_velocity=np.zeros(3)
            else:self.robot_velocity=np.zeros(3)
            path=self._remaining_trajectory()[0] if self.trajectory.status=='ok' else None
        timings['planning']=1000*(time.perf_counter()-stage)
        # The displayed TTC and simulated robot diagnostics share one snapshot.
        entities,self.geofences,_=self.risk.evaluate(entities,self.geofences,self.robot_position,self.robot_velocity)
        latency=1000*(time.perf_counter()-start);self.processing_ms.append(latency)
        rss=psutil.Process().memory_info().rss/1024**2;self.memory_mb.append(rss)
        colors=PALETTE[probs.argmax(1)] if len(probs) else np.empty((0,3))
        inlay=frame.gemini_rgbd_cloud
        if inlay is not None:inlay=np.c_[transform_points(pose,inlay[:,:3]),inlay[:,3:]]
        diagnostics={**frame.diagnostics,**self.deskewer.last_diagnostics,'module_ms':timings,'processing_ms':latency,
            'memory_mb':rss,'queue_depth':getattr(self,'presentation_queue_depth',0),'dropped_snapshots':self.dropped_snapshots,
            'end_to_end_fps':(self.frames+1)/max(time.monotonic()-self.started,1e-6),
            'trajectory_status':self.trajectory.status,'trajectory_reason':self.trajectory.reason,
            'planner':self.planner.last_diagnostics,'robot_position':self.robot_position.tolist(),
            'robot_velocity':self.robot_velocity.tolist(),'checkpoint_synthetic_only':self.inference.metadata.get('synthetic_only'),'hardware_validated':False,
            'occupancy_cells':len(self.occupancy.cells),'active_voxels':len(colors),
            'traffic_grid':{'bounds_xy':self.heatmap.bounds,'resolution_m':self.heatmap.resolution,'decay_seconds':self.heatmap.decay_seconds}}
        if self.mobile:
            diagnostics['localization']={key:value for key,value in self.odometry.last_diagnostics.items() if np.isscalar(value)}
        state=TwinMasterFrameState(raw_frame.frame_id,aligned_time,1000/max(latency,.001),pose,tuple(entities),
            prepared.voxels.voxel_centers,colors,flow,self.floor_points,risk,risk_colors,heat,tuple(self.geofences),path,
            inlay,tuple(self.alert_log),diagnostics,self.trajectory.status)
        self.last_state=state;self.frames+=1;self.last_time=aligned_time
        return state

    def report(self):
        p=np.array(self.processing_ms);m=np.array(self.memory_mb)
        elapsed=time.monotonic()-self.started
        return {'schema_version':1,'frames':self.frames,'wall_seconds':elapsed,'end_to_end_fps':self.frames/max(elapsed,1e-6),
            'processing_latency_ms':{'p50':float(np.percentile(p,50)),'p95':float(np.percentile(p,95)),'max':float(p.max())} if len(p) else {},
            'mean_processing_fps':float(1000/p.mean()) if len(p) else 0.,
            'rss_mb':{'first':float(m[0]),'last':float(m[-1]),'max':float(m.max()),'last_half_slope_mb_per_frame':float(np.polyfit(np.arange(len(m)//2,len(m)),m[len(m)//2:],1)[0]) if len(m)>4 else 0.} if len(m) else {},
            'dropped_snapshots':self.dropped_snapshots,'occupancy_cells':len(self.occupancy.cells),
            'presentation_queue':{'capacity':2,'current_depth':getattr(self,'presentation_queue_depth',0),
                'max_depth':getattr(self,'presentation_queue_max_depth',0)},
            'configuration':self.config,'input_mode':self.config.get('input_mode','unspecified'),
            'hardware_validation':'physical devices and real-lab accuracy have not been validated by this delivery'}
